function TaskList({ tasks, toggleTask, deleteTask }) {
  if (tasks.length === 0) {
    return <p className="empty">No tasks yet.</p>;
  }

  return (
    <ul className="task-list">
      {tasks.map((task) => (
        <li
          key={task.id}
          className={`task ${task.completed ? "done" : ""}`}
          onClick={() => toggleTask(task.id)}
        >
          <div className="task-main">
            <span className={`priority ${task.priority}`} />
            {task.title}
          </div>

          <button
            className="delete"
            onClick={(e) => {
              e.stopPropagation();
              deleteTask(task.id);
            }}
          >
            ✕
          </button>
        </li>
      ))}
    </ul>
  );
}

export default TaskList;
